<?php

/**
 *
 * Copyright (C) 2011 Pear Technology Investments, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @copyright	$Copyrights:$
 * @license		$License:$
 * @category		PearCMS
 * @package		PearCMS Hebrew Language Pack
 * @author		$Author:$
 * @version		$Id:$
 * @link			$Link:$
 * @since		$Since:$
 */


return array(
	'starter_kit__basic__name'			=>	'בסיס',
	'starter_kit__basic__description'	=>	'ערכה זו תחבר המערכת בהגדרות הבסיס וברירת המחדל של המערכת. בנוסף, תוסיף המרכת כמה תכני דוגמא להצגת היכולות הבסיסיות של המערכת.',
	'cannot_write_cats' => 'לא היה ניתן לכתוב קטגוריות לדוגמא.<br />
	פרטי השגיאה: %s',
	'writing_cats' => 'כותב קטגוריות לדוגמא...',
	'cannot_write_pages' => 'לא היה ניתן לכתוב דפים לדוגמא.<br />
	פרטי השגיאה: %s',
	'writing_pages' => 'כותב דפים לדוגמא...',
	'cannot_write_layouts' => 'לא היה ניתן לכתוב את תבניות התצוגה לדוגמא<br />פרטי השגיאה: %s',
	'writing_layouts' => 'כותב תבניות תצוגה לדוגמא...',


	'starter_kit__business__name'		=>	'עסקים',
	'starter_kit__business__description'	=>	'ערכה זו מתאימה לאתרי עסקים וחברות. בנוסף להגדרת המערכת באופן המתאים לאתרי עסקים, תיצור המערכת מאמרי דוגמה המופיעים בדרך כלל באתרי עסקים וחברות.',
	
	'starter_kit__blog__name'			=>	'בלוג',
	'starter_kit__blog__description'		=>	'ערכה זו מתאימה לבלוגים. הערכה מגדירה את המערכת בהגדרות המאפשרות ליצור בלוג (סידור מאמרים ופוסטים) ומציגה את רשימת הפוסטים האחרונים בעמוד הראשי. בנוסף, תוסיף המערכת פוסט ועמוד לדוגמא בכדי להדגים את תצורת הבלוג שלך.',

	'starter_kit__content__name'			=>	'תוכן',
	'starter_kit__content__description'	=>	'ערכה זו מתאימה לאתרים מונחי תוכן. הערכה מגדירה את המערכת בהגדרות המתאימות לאתר תכנים, בעל עמוד ראשי סטאטי, ויוצרת כמה עמודים לדוגמא.',

);

?>