<?php

/**
 *
 * Copyright (C) 2011 Pear Technology Investments, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @copyright	$Copyrights:$
 * @license		$License:$
 * @category		PearCMS
 * @package		PearCMS Hebrew Language Pack
 * @author		$Author:$
 * @version		$Id:$
 * @link			$Link:$
 * @since		$Since:$
 */


return array (
  'group_name_admins' => 'מנהלים ראשים',
  'group_name_staff' => 'צוות',
  'group_name_members' => 'משתמשים',
  'group_name_guests' => 'אורחים',
  'group_name_validating' => 'ממתינים לאישור',
  'group_name_banned' => 'מורחקים',
  'site_name_blog_pattern' => 'הבלוג של %s',
  'security_tools__admincp_directory' => 'Admin CP Directory Name',
  'security_tools_desc__admincp_directory' => 'We recommend to change the AdminCP directory name from "Admin/" to something else in order to be diffrant from the offical distributed PearCMS structure.',
  'security_tools__antivirus_basic' => 'Anti-Virus Basic Scan',
  'security_tools_desc__antivirus_basic' => 'Scan the system files from damaged and viruses files.',
  'security_tools__antivirus_ftp' => 'Anti-Virus FTP Scan',
  'security_tools_desc__antivirus_ftp' => '',
  'security_tools__pearcms_installer_block' => 'PearCMS Installer Wizard Block',
  'security_tools_desc__pearcms_installer_block' => 'PearCMS auto-create a file named &quot;InstallerLock.php&quot; in order to disable the installer from been accessed. In case that this file not exists, you must create it in order to disable the installer.',
  'secret_question__1' => 'מהו המאכל האהוב עליך',
  'secret_question__2' => 'מה מספר הטלפון הראשון שלך',
  'secret_question__3' => 'מהי העיר בה נולדת',
  'secret_question__4' => 'מי הדמות אותה הערצת בילדותך',
  'secret_question__5' => 'מהו מקום עבודתך הראשון',
  'test_directory_name' => 'תיקית הדגמה',
  'test_directory_description' => 'זוהי תיקיה הנוצרה באופן אוטומטי על ידי PearCMS בכדי להמחיש את מנגנון התיקיות במערכת.
באפשרותך להוסיף לתיקיה דפים הישמשו כדפי תוכן או מאמרים, ותתי תיקיות.',
  'main_page_title' => 'ראשי',
  'main_page_description' => 'עמוד השער של האתר',
  'main_page_content' => '<div >ברוך הבא למערכת PearCMS!<br />אם אתה רואה עמוד זה, סימן שהמערכת הותקנה בהצלחה באתרך.<br />זהו הדף הראשי של אתרך, אתה יכול לערוך את תוכן דך זה או לבחור בדף אחר במידה ותרצה. בכדי להוסיף עוד עמודים התחבר לחשבון המנהל הראשי שהגדרת במהלך ההתקנה, היכנס ללוח הבקרה למנהלים ומשם לניהול תכנים -> הוסף עמוד חדש.<br /><br />מאחלים בהצלחה בהמשך דרכך, צוות PearCMS.</div>',
  'error_page_title' => 'דף לא נמצא (404)',
  'error_page_description' => 'עמוד מותאם אישית להצגת שגיאה בנוגע לדפים הלא קיימים.',
  'error_page_content' => '<div class="ErrorMessage">העמוד המבוקש לא נמצא.</div>',
  'test_page_title' => 'עמוד נסיון',
  'test_page_description' => 'זהו עמוד ניסיון להדגמת מנגנון התיקיות והעמודים במערכת.',
  'test_page_content' => '<h2>זהו עמוד ניסיון הנוצר באופן אוטומטי</h2><div>אם אתה רואה עמוד זה, סימן שהמערכת הותקנה ומתפקדת כהלכה.<br />אתה יכול למחוק או לערוך עמוד זה.<br />לכל שאלה בנוגע למערכת ניתן לגשת ל<a href="http://community.pearcms.com">פורומי התמיכה</a> או לשלוח מייל ישירות לצוות דרך <a href="mailto:support@pearcms.com">לחיצה כאן</a><br />בברכת הצלחה בהמשך הדרך,<br />צוות PearCMS.</div>',
  'acp_section__settings' => 'הגדרות',
  'acp_section_desc__settings' => 'באזור זה תוכל לנהל את ההגדרות הכלליות של אתרך.',
  'acp_section__members' => 'משתמשים &amp; קבוצות משתמשים',
  'acp_section_desc__members' => 'כאן תוכל לנהל את המשתמשים וקבוצות מהשתמשים באתר.',
  'acp_section__content' => 'ניהול תוכן',
  'acp_section_desc__content' => 'באזור זה תוכל לנהל את התוכן באתרך.',
  'acp_section__design' => 'עיצוב &amp; שפה',
  'acp_section_desc__design' => 'באזור זה תוכל לנהל את העיצוב והשפה באתרך.',
  'acp_section__diagnostics' => 'כלי אבחון',
  'acp_section_desc__diagnostics' => 'באזור זה תוכל לנהל ולצפות בסטטיסטיקות על אתרך, לצפות בנתונים אודות מסד הנתונים שלך, לגבות את מסד הנתונים ועוד.',
  'acp_section__addons' => 'תוספות',
  'acp_section_desc__addons' => 'באזור זה תוכל לנהל את התוספות באתרך, ליצור, להתקין ולהסיר תוספות אשר הורדת מחנות התוספות של PearCMS.',
  'acp_section_page__general_settings' => 'הגדרות כלליות',
  'acp_section_page_desc__general_settings' => 'בעמוד זה תוכל לנהל את ההגדרות הכלליות של אתרך.',
  'acp_section_page__toggle_site_status' => 'כיבויי / הפעלת האתר',
  'acp_section_page_desc__toggle_site_status' => 'בעמוד זה תוכל לכבות או להפעיל את מערכת האתר.',
  'acp_section_page__manage_cp_pages_permissions' => 'אזורים ועמודים בלוח הבקרה',
  'acp_section_page_desc__manage_cp_pages_permissions' => 'בעמוד זה תוכל לנהל את האזורים והעמודים בלוח הבקרה למנהלים, ולקבוע הרשאות גישה לכל קבוצת משתמשים.',
  'acp_section_page__recache_utils' => 'ניהול מטמון',
  'acp_section_page_desc__recache_utils' => 'באזור זה תוכל לנהל את המטמון של המערכת.',
  'acp_section_page__manage_groups' => 'ניהול קבוצות משתמשים',
  'acp_section_page_desc__manage_groups' => 'באזור זה תוכל לנהל את קבוצות המשתמשים באתרך.',
  'acp_section_page__manage_members' => 'ניהול משתמשים',
  'acp_section_page_desc__manage_members' => 'באזור זה תוכל לנהל את המשתמשים הרשומים לאתרך.',
  'acp_section_page__manage_bans' => 'ניהול הרחקות',
  'acp_section_page_desc__manage_bans' => 'באזור זה תוכל לנהל את הרחקות המשתמשים מאתרך.',
  'acp_section_page__manage_secret_questions' => 'רשימת שאלות סודיות',
  'acp_section_page_desc__manage_secret_questions' => 'באזור זה תוכל להגדיר את השאלות הסודיות הניתנות למשתמש לבחירה בעת ההרשמה.',
  'acp_section_page__content_manager' => 'ניהול עמודים ותיקיות',
  'acp_section_page_desc__content_manager' => 'באזור זה תוכל לנהל את העמודים והתיקיות באתרך.',
  'acp_section_page__manage_polls' => 'סקרים',
  'acp_section_page_desc__manage_polls' => 'באזור זה תוכל לנהל את הסקרים באתרך.',
  'acp_section_page__manage_newsletters' => 'רשימות תפוצה',
  'acp_section_page_desc__manage_newsletters' => 'באזור זה תוכל לנהל את רשימות התפוצה באתרך, להוסיף רשימת תפוצה חדשה וכו".',
  'acp_section_page__send_newsletter' => 'שליחת עיתון',
  'acp_section_page_desc__send_newsletter' => 'בעמוד זה תוכל לשלוח דואר (עיתון) לנרשמים לרשימות התפוצה שלך.',
  'acp_section_page__blocks_manager' => 'ניהול בלוקים',
  'acp_section_page_desc__blocks_manager' => 'נהל את הבלוקים (וויגטים) המופיעים באתרך.',
  'acp_section_page__rss_manager' => 'ניהול הזנות (RSS)',
  'acp_section_page_desc__rss_manager' => 'באזור זה תוכל לנהל את ההזנות אותם מספק האתר.',
  'acp_section_page__content_layouts' => 'תבניות תצוגה',
  'acp_section_page_desc__content_layouts' => 'באזור זה תוכל להגדיר תבניות תצוגה לתוכן אותו אתה יוצר לאתרך.',
  'acp_section_page__manage_menu' => 'ניהול תפריט',
  'acp_section_page_desc__manage_menu' => 'באזור זה תוכל לנהל את התפריט הראשי באתרך.',
  'acp_section_page__manage_themes' => 'ערכות נושא',
  'acp_section_page_desc__manage_themes' => 'בעמוד זה תוכל לנהל את ערכות הנושא באתרך.',
  'acp_section_page__manage_languages' => 'ניהול שפות',
  'acp_section_page_desc__manage_languages' => 'בעמוד זה תוכל לנהל את השפות באתרך.',
  'acp_section_page__create_language_file' => 'צור קובץ שפה',
  'acp_section_page_desc__create_language_file' => 'בעמוד זה תוכל ליצור קובץ שפה חדש.',
  'acp_section_page__manage_sql_db' => 'ניהול מסד נתונים',
  'acp_section_page_desc__manage_sql_db' => 'באזור זה תוכל לנהל את מסד הנתונים שלך, את סכימות הנתונים וכו".',
  'acp_section_page__db_backup' => 'גיבויי מסד נתונים',
  'acp_section_page_desc__db_backup' => 'בעמוד זה תוכל לגבות את מסד הנתונים שלך דרך לוח הבקרה.',
  'acp_section_page__upload_db_backup' => 'העלאת גיבויי למסד הנתונים',
  'acp_section_page_desc__upload_db_backup' => 'בעמוד זה תוכל להעלות גיבויי למסד הנתונים שלך.',
  'acp_section_page__security_center' => 'מרכז האבטחה',
  'acp_section_page_desc__security_center' => '',
  'acp_section_page__manage_addons' => 'ניהול תוספים',
  'acp_section_page_desc__manage_addons' => 'באזור זה תוכל ליצור, לערוך ולהתקין תוספים אשר יתאימו את האתר לדרישותיך.',
);